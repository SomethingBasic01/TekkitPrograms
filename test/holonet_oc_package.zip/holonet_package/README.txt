HOLO-NET for OpenComputers
==========================

Files
-----
console.lua         Main control terminal / menu UI
scan_node.lua       Runs on a geolyzer node
projector_node.lua  Runs on a hologram projector node

What it does
------------
- Discovers scanner nodes and projector nodes over the modem network.
- Captures voxel scenes from one or more geolyzer stations.
- Saves and loads scene files.
- Projects a selected scene to all projector nodes.
- Supports live auto-refresh scenes.
- Supports large stitched displays by assigning different global tile origins
  to different projector nodes.

Required hardware
-----------------
Console computer:
- Computer + screen + keyboard + GPU
- Wireless modem or network path to all nodes

Scanner node:
- Computer
- Geolyzer
- Wireless modem or linked/network connection
- OPTIONAL but recommended: place it where the geolyzer position is easy to know

Projector node:
- Computer
- Hologram projector
- Wireless modem or linked/network connection

Important setup note
--------------------
For scanner nodes, WORLD_X / WORLD_Y / WORLD_Z must be the ACTUAL block
coordinates of the geolyzer block itself. The scan coordinates are relative to
that geolyzer.

For projector nodes, TILE_X / TILE_Y / TILE_Z define which part of the global
scene that projector is responsible for. Example:
- projector-1 renders X 0..47, Y 48..79, Z 0..47
- projector-2 renders X 48..95, Y 48..79, Z 0..47
This is how you stitch a larger display.

Recommended defaults
--------------------
- Start with one scanner and one projector first.
- Use mode = bands or dense for best readability.
- Use a 48x48x32 box when testing.
- Use live mode only after a normal capture works.

Suggested install
-----------------
1) Copy the files somewhere convenient, for example /home/holonet/
2) Edit the config block at the top of each file.
3) On the scanner computer:   lua scan_node.lua
4) On the projector computer: lua projector_node.lua
5) On the console computer:   lua console.lua

Console keys
------------
C  capture a scene
L  toggle live mode
P  project selected scene
S  save selected scene to /home/holonet_scenes/
O  open/load a saved .scene file
X  delete selected scene from memory
N  select next scene
B  select previous scene
K  clear all projectors
R  rediscover nodes
Q  quit

Modes
-----
void   shows near-air readings
solid  shows everything non-air
dense  shows only high-hardness readings
bands  uses 3 value bands for nicer color separation

Caveats
-------
- Geolyzer data is hardness-based, not a perfect block camera.
- Large/complex scenes can take many packets.
- Overlapping scanners will merge by coordinate, last value wins.
- Projectors are physically small, so truly large displays still require
  multiple projector blocks arranged in the world.
